<?php
/**
 * Without this file, WordPress will consider the theme broken.
 */