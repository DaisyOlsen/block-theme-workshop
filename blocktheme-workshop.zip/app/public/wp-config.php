<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'aR2alpuHEWYyBO/diokJHCzMvNkz5/ZOhogcJJsvu8GsFUP7muKF32g3xePuZa0XpfN3drmlYEq1cQESLrkddg==');
define('SECURE_AUTH_KEY',  'yvTwbRlkfVF6VR+YcXKq8D/tUoVAj/w9i1WvsT+QXcx53nMqI4bO36FZJzX/ZicoExH+QfQmX+UBgKtEcEFPmA==');
define('LOGGED_IN_KEY',    'YenxCf9zwbDYQb8VkjCXZWk+6bxJaCw01IWx2Zdhp+7xJqsVGEqMS1UeCto0e/vbIKn6UIGr4yT/tW3wm0hh9Q==');
define('NONCE_KEY',        'p2hrUTP4GP9E17ScR3ZlE+W+xPUXXA9WI6a/LAiPaudCgKjor9eJfIpvZ28I1ikqNF8od56ybdxZmfClfzvYyQ==');
define('AUTH_SALT',        'SNrf1LqopJtXp2xiYaJtfjr5CeX3kw9x58sJWrVhcC7ixIlAO02der52wwT7xNPzBYIRZSUwf5BOdPaMdGO2qA==');
define('SECURE_AUTH_SALT', 'FCV9+HPID3wVkIe6Lf0voejcdvBdShuDym3Rn4cWEj6M+r+3FEh3H2He99rSwzwUVeB/gIrRhvowGHSlqhwx1w==');
define('LOGGED_IN_SALT',   '2WcRrLHpd6JFfnSs6SWydbx+wjHh+9FqsQ1OlxPq6vp32yGNB/5+4CrFgH4JE/HvQdMUV4a0mjJARrJ6s+Iw7Q==');
define('NONCE_SALT',       '33KXocQlRyEWMfPKOkJN/nNreA3zCA1n7g1s6TB8a4RhgKQOUHHm8npDHA/+mnXovOAERBqHi7E47B+U+z8HKQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
